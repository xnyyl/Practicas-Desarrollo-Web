package mx.edu.backendacademico.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.httpBasic;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;

import java.util.UUID;
import java.util.concurrent.Callable;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.http.MediaType;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;
import org.testcontainers.postgresql.PostgreSQLContainer;

@SpringBootTest
@AutoConfigureMockMvc
@Testcontainers
class AlumnoIdempotenciaIntegrationTest {

    @Container
    static PostgreSQLContainer postgres = new PostgreSQLContainer("postgres:17-alpine");

    @DynamicPropertySource
    static void configurarDatasource(DynamicPropertyRegistry registry) {
        registry.add("spring.datasource.url", postgres::getJdbcUrl);
        registry.add("spring.datasource.username", postgres::getUsername);
        registry.add("spring.datasource.password", postgres::getPassword);
    }

    @Autowired
    private MockMvc mockMvc;

    @Test
    void dosSolicitudesSimultaneasConMismaClaveCreanUnSoloAlumnoYDevuelvenLaMismaRespuesta() throws Exception {
        String claveIdempotencia = "idem-" + UUID.randomUUID();
        String payload = """
            {
              "matricula": "A20269001",
              "nombre": "Ada Lovelace",
              "correo": "ada.lovelace@uanl.edu.mx"
            }
            """;

        ExecutorService pool = Executors.newFixedThreadPool(2);
        CountDownLatch barreraInicio = new CountDownLatch(1);

        Callable<MvcResult> tareaPost = () -> {
            barreraInicio.await();
            return mockMvc.perform(post("/api/v1/alumnos")
                            .with(httpBasic("docente", "docente123"))
                            .with(csrf())
                            .header("Idempotency-Key", claveIdempotencia)
                            .contentType(MediaType.APPLICATION_JSON)
                            .content(payload))
                    .andReturn();
        };

        Future<MvcResult> futuro1 = pool.submit(tareaPost);
        Future<MvcResult> futuro2 = pool.submit(tareaPost);

        barreraInicio.countDown();

        MvcResult res1 = futuro1.get(10, TimeUnit.SECONDS);
        MvcResult res2 = futuro2.get(10, TimeUnit.SECONDS);
        pool.shutdown();

        assertEquals(201, res1.getResponse().getStatus());
        assertEquals(201, res2.getResponse().getStatus());
        assertEquals(res1.getResponse().getHeader("Location"), res2.getResponse().getHeader("Location"));
        assertEquals(res1.getResponse().getContentAsString(), res2.getResponse().getContentAsString());
    }

    @Test
    void mismaClaveConDistintoContenidoSeRechazaSinCrearSegundoAlumno() throws Exception {
        String claveIdempotencia = "idem-" + UUID.randomUUID();

        String primerPayload = """
            {
              "matricula": "A20269002",
              "nombre": "Grace Hopper",
              "correo": "grace.hopper@uanl.edu.mx"
            }
            """;

        String segundoPayloadDistinto = """
            {
              "matricula": "A20269003",
              "nombre": "Margaret Hamilton",
              "correo": "margaret.hamilton@uanl.edu.mx"
            }
            """;

        MvcResult primera = mockMvc.perform(post("/api/v1/alumnos")
                        .with(httpBasic("docente", "docente123"))
                        .with(csrf())
                        .header("Idempotency-Key", claveIdempotencia)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(primerPayload))
                .andReturn();

        assertEquals(201, primera.getResponse().getStatus());

        MvcResult segunda = mockMvc.perform(post("/api/v1/alumnos")
                        .with(httpBasic("docente", "docente123"))
                        .with(csrf())
                        .header("Idempotency-Key", claveIdempotencia)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(segundoPayloadDistinto))
                .andReturn();

        int statusSegunda = segunda.getResponse().getStatus();
        assertTrue(statusSegunda == 422 || statusSegunda == 409,
                "Se esperaba 422 o 409 por reutilización de clave con distinto payload, pero fue: " + statusSegunda);
        assertEquals("application/problem+json", segunda.getResponse().getContentType());
    }
}