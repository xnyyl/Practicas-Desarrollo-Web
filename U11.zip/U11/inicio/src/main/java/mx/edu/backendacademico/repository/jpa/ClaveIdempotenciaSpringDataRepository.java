package mx.edu.backendacademico.repository.jpa;

import jakarta.persistence.LockModeType;
import java.time.Instant;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface ClaveIdempotenciaSpringDataRepository extends JpaRepository<ClaveIdempotenciaEntity, Long> {

    @Modifying
    @Query(value = """
        INSERT INTO claves_idempotencia (solicitante, clave, huella_sha256, estado, creada_en, expira_en)
        VALUES (:solicitante, :clave, :huella, 'EN_PROCESO', :creadaEn, :expiraEn)
        ON CONFLICT (solicitante, clave) DO NOTHING
        """, nativeQuery = true)
    int reservarSiNoExiste(
            @Param("solicitante") String solicitante,
            @Param("clave") String clave,
            @Param("huella") String huella,
            @Param("creadaEn") Instant creadaEn,
            @Param("expiraEn") Instant expiraEn
    );

    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("SELECT c FROM ClaveIdempotenciaEntity c WHERE c.solicitante = :solicitante AND c.clave = :clave")
    Optional<ClaveIdempotenciaEntity> buscarParaActualizar(
            @Param("solicitante") String solicitante,
            @Param("clave") String clave
    );
}