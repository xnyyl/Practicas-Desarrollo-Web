package mx.edu.backendacademico.repository.jpa;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.time.Instant;

@Entity
@Table(name = "claves_idempotencia")
public class ClaveIdempotenciaEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 100)
    private String solicitante;

    @Column(nullable = false, length = 120)
    private String clave;

    @Column(name = "huella_sha256", nullable = false, length = 64)
    private String huellaSha256;

    @Column(nullable = false, length = 20)
    private String estado;

    @Column(name = "status_respuesta")
    private Integer statusRespuesta;

    @Column(name = "cuerpo_respuesta")
    private String cuerpoRespuesta;

    @Column(name = "location_respuesta", length = 255)
    private String locationRespuesta;

    @Column(name = "creada_en", nullable = false)
    private Instant creadaEn;

    @Column(name = "expira_en", nullable = false)
    private Instant expiraEn;

    protected ClaveIdempotenciaEntity() {
    }

    public Long getId() { return id; }
    public String getSolicitante() { return solicitante; }
    public String getClave() { return clave; }
    public String getHuellaSha256() { return huellaSha256; }
    public String getEstado() { return estado; }
    public Integer getStatusRespuesta() { return statusRespuesta; }
    public String getCuerpoRespuesta() { return cuerpoRespuesta; }
    public String getLocationRespuesta() { return locationRespuesta; }

    public void completar(int status, String location, String cuerpoJson) {
        this.estado = "COMPLETADA";
        this.statusRespuesta = status;
        this.locationRespuesta = location;
        this.cuerpoRespuesta = cuerpoJson;
    }
}