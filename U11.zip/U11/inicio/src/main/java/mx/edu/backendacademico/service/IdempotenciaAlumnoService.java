package mx.edu.backendacademico.service;

import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.Duration;
import java.time.Instant;
import java.util.HexFormat;
import java.util.Locale;
import mx.edu.backendacademico.dto.AlumnoMapper;
import mx.edu.backendacademico.dto.AlumnoResponse;
import mx.edu.backendacademico.dto.CrearAlumnoRequest;
import mx.edu.backendacademico.exception.IdempotenciaConflictoException;
import mx.edu.backendacademico.repository.jpa.ClaveIdempotenciaSpringDataRepository;
import org.springframework.context.annotation.Profile;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import tools.jackson.databind.ObjectMapper;

@Service
@Profile("jpa")
public class IdempotenciaAlumnoService {

    private final ClaveIdempotenciaSpringDataRepository idempotenciaRepository;
    private final AlumnoService alumnoService;
    private final ObjectMapper objectMapper;

    public IdempotenciaAlumnoService(
            ClaveIdempotenciaSpringDataRepository idempotenciaRepository,
            AlumnoService alumnoService,
            ObjectMapper objectMapper) {
        this.idempotenciaRepository = idempotenciaRepository;
        this.alumnoService = alumnoService;
        this.objectMapper = objectMapper;
    }

    @Transactional
    public ResponseEntity<AlumnoResponse> crearIdempotente(
            String solicitante, String clave, CrearAlumnoRequest request) {
        String claveLimpia = clave.trim();
        if (claveLimpia.isEmpty() || claveLimpia.length() > 120) {
            throw new IdempotenciaConflictoException("La cabecera Idempotency-Key debe tener entre 1 y 120 caracteres");
        }

        String huella = calcularHuellaSha256(request);
        Instant ahora = Instant.now();

        // Reserva atómica a nivel de motor PostgreSQL; el segundo hilo concurrente obtiene 0 filas afectadas
        // y espera al commit del primero en buscarParaActualizar (SELECT ... FOR UPDATE).
        idempotenciaRepository.reservarSiNoExiste(
                solicitante, claveLimpia, huella, ahora, ahora.plus(Duration.ofHours(24))
        );

        var registro = idempotenciaRepository.buscarParaActualizar(solicitante, claveLimpia)
                .orElseThrow(() -> new IllegalStateException("No se pudo recuperar el registro de idempotencia"));

        if (!registro.getHuellaSha256().equals(huella)) {
            throw new IdempotenciaConflictoException(
                    "La clave de idempotencia ya fue utilizada con un contenido diferente");
        }

        if ("COMPLETADA".equals(registro.getEstado())) {
            var cuerpoOriginal = objectMapper.readValue(registro.getCuerpoRespuesta(), AlumnoResponse.class);
            return ResponseEntity.status(registro.getStatusRespuesta())
                    .location(URI.create(registro.getLocationRespuesta()))
                    .header("Idempotency-Replayed", "true")
                    .body(cuerpoOriginal);
        }

        var creado = alumnoService.crear(request.matricula(), request.nombre(), request.correo());
        var respuestaDto = AlumnoMapper.toResponse(creado);
        String location = "/api/v1/alumnos/" + creado.id();

        registro.completar(201, location, objectMapper.writeValueAsString(respuestaDto));

        return ResponseEntity.created(URI.create(location)).body(respuestaDto);
    }

    private String calcularHuellaSha256(CrearAlumnoRequest request) {
        String canonico = String.join("|",
                request.matricula().trim().toUpperCase(Locale.ROOT),
                request.nombre().trim(),
                request.correo().trim().toLowerCase(Locale.ROOT)
        );
        try {
            byte[] digest = MessageDigest.getInstance("SHA-256")
                    .digest(canonico.getBytes(StandardCharsets.UTF_8));
            return HexFormat.of().formatHex(digest);
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException("Algoritmo SHA-256 no disponible", e);
        }
    }
}
