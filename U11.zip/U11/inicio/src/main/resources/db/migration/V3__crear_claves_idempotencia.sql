CREATE TABLE claves_idempotencia (
                                     id                 BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
                                     solicitante        VARCHAR(100) NOT NULL,
                                     clave              VARCHAR(120) NOT NULL,
                                     huella_sha256      VARCHAR(64)  NOT NULL,
                                     estado             VARCHAR(20)  NOT NULL,
                                     status_respuesta   INT,
                                     cuerpo_respuesta   TEXT,
                                     location_respuesta VARCHAR(255),
                                     creada_en          TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
                                     expira_en          TIMESTAMP    NOT NULL,
                                     CONSTRAINT uk_idempotencia_solicitante_clave UNIQUE (solicitante, clave),
                                     CONSTRAINT chk_idempotencia_estado CHECK (estado IN ('EN_PROCESO', 'COMPLETADA'))
);